import { useState, type ReactNode, type ElementType } from "react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { Toaster } from "sonner";
import {
  LayoutDashboard, Play, MessageCircle, TrendingUp, Trophy,
  Users, ClipboardList, BarChart3, CheckSquare, Bell,
  ChevronRight, Menu, X, Target, Star, Flame, AlertTriangle,
  CheckCircle, Activity, Cpu, Database, UserCircle, Plus,
  Edit3, Video, Send, ArrowUp, ArrowDown, Clock, Shield,
  Zap, Calendar, Award, Heart, RefreshCw, Settings,
  ChevronDown, Stethoscope, Brain, Layers,
} from "lucide-react";
import {
  AreaChart, Area, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Legend, ReferenceLine,
} from "recharts";

// ─── Data ─────────────────────────────────────────────────────────────────────

const romHistory = [
  { session: "S1",  flexion: 51, extension: 28, quality: 71, date: "Jun 1"  },
  { session: "S2",  flexion: 55, extension: 24, quality: 74, date: "Jun 3"  },
  { session: "S3",  flexion: 63, extension: 20, quality: 77, date: "Jun 5"  },
  { session: "S4",  flexion: 68, extension: 18, quality: 79, date: "Jun 7"  },
  { session: "S5",  flexion: 72, extension: 15, quality: 81, date: "Jun 9"  },
  { session: "S6",  flexion: 79, extension: 12, quality: 83, date: "Jun 11" },
  { session: "S7",  flexion: 85, extension: 10, quality: 85, date: "Jun 13" },
  { session: "S8",  flexion: 89, extension:  8, quality: 87, date: "Jun 15" },
  { session: "S9",  flexion: 92, extension:  7, quality: 88, date: "Jun 17" },
  { session: "S10", flexion: 95, extension:  5, quality: 88, date: "Jun 19" },
];

const adherenceData = [
  { week: "Wk 1", completed: 4, target: 5, quality: 74 },
  { week: "Wk 2", completed: 5, target: 5, quality: 78 },
  { week: "Wk 3", completed: 4, target: 5, quality: 80 },
  { week: "Wk 4", completed: 6, target: 5, quality: 84 },
  { week: "Wk 5", completed: 5, target: 5, quality: 87 },
  { week: "Wk 6", completed: 6, target: 5, quality: 88 },
];

const patients = [
  { id: 1, name: "Margaret Chen",   initials: "MC", age: 67, condition: "TKR Recovery",       stage: "Week 6",  flexion: 95,  extension: 5,  compliance: 88, status: "improving", last: "2 hours ago",    trend: "+8°" },
  { id: 2, name: "Robert Okafor",   initials: "RO", age: 54, condition: "Osteoarthritis",      stage: "Week 3",  flexion: 72,  extension: 18, compliance: 62, status: "attention", last: "3 days ago",     trend: "+3°" },
  { id: 3, name: "Sarah Lindqvist", initials: "SL", age: 41, condition: "ACL Sports Injury",   stage: "Week 10", flexion: 118, extension: 2,  compliance: 95, status: "improving", last: "1 hour ago",     trend: "+5°" },
  { id: 4, name: "David Mensah",    initials: "DM", age: 72, condition: "TKR Recovery",        stage: "Week 2",  flexion: 58,  extension: 22, compliance: 74, status: "stable",    last: "Yesterday",      trend: "+2°" },
  { id: 5, name: "Patricia Walsh",  initials: "PW", age: 60, condition: "Osteoarthritis",      stage: "Week 8",  flexion: 103, extension: 8,  compliance: 80, status: "improving", last: "4 hours ago",    trend: "+6°" },
  { id: 6, name: "James Ikenna",    initials: "JI", age: 48, condition: "Meniscus Repair",     stage: "Week 5",  flexion: 88,  extension: 10, compliance: 45, status: "attention", last: "4 days ago",     trend: "0°"  },
];

const dailyExercises = [
  { id: 1, name: "Straight Leg Raise",      sets: 3, reps: 10, duration: "~8 min",  muscle: "Quadriceps" },
  { id: 2, name: "Heel Slides",             sets: 3, reps: 15, duration: "~10 min", muscle: "Hamstrings" },
  { id: 3, name: "Seated Knee Extension",   sets: 3, reps: 12, duration: "~9 min",  muscle: "Quadriceps" },
  { id: 4, name: "Terminal Knee Extension", sets: 3, reps: 12, duration: "~8 min",  muscle: "Quads / VMO" },
  { id: 5, name: "Wall Slides",             sets: 2, reps: 10, duration: "~7 min",  muscle: "Multiple"   },
];

const heatmap = Array.from({ length: 42 }, (_, i) => {
  const missed = [5, 6, 12, 19, 26];
  if (missed.includes(i) || i >= 40) return 0;
  return i % 7 === 6 ? 0 : Math.min(4, Math.floor((i % 5) + 1));
});

const chatHistory = [
  { id: 1, role: "ai",      type: "physio",  content: "Excellent work in today's session, Margaret. Your heel slides showed a marked improvement in range compared to last week." },
  { id: 2, role: "ai",      type: "insight", content: "Your knee flexion reached 95° during the seated extensions — that is a personal best. You have improved 8° this week alone." },
  { id: 3, role: "ai",      type: "tip",     content: "Try to maintain a slower, more controlled descent during the straight leg raise. This engages your quadriceps more effectively." },
  { id: 4, role: "ai",      type: "physio",  content: "Based on your current trajectory, you are on track to achieve full knee extension within 2 weeks. Outstanding progress." },
];

// ─── Primitive Components ─────────────────────────────────────────────────────

type BadgeVariant = "success" | "warning" | "danger" | "info" | "neutral";

function Badge({ children, variant = "neutral" }: { children: ReactNode; variant?: BadgeVariant }) {
  const map: Record<BadgeVariant, string> = {
    success: "bg-emerald-50 text-emerald-700 border border-emerald-200",
    warning: "bg-amber-50 text-amber-700 border border-amber-200",
    danger:  "bg-red-50 text-red-600 border border-red-200",
    info:    "bg-blue-50 text-blue-700 border border-blue-200",
    neutral: "bg-slate-100 text-slate-600",
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap ${map[variant]}`}>
      {children}
    </span>
  );
}

function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`bg-white rounded-2xl shadow-sm border border-slate-100 ${className}`}>
      {children}
    </div>
  );
}

function StatPill({ label, value, unit, sub, color = "blue", icon: Icon }: {
  label: string; value: string; unit?: string; sub?: string;
  color?: "blue" | "teal" | "green" | "amber" | "purple"; icon?: ElementType;
}) {
  const pal = {
    blue:   { bg: "bg-blue-50",    text: "text-blue-700",    subtle: "text-blue-500",    iconBg: "bg-blue-100"    },
    teal:   { bg: "bg-teal-50",    text: "text-teal-700",    subtle: "text-teal-500",    iconBg: "bg-teal-100"    },
    green:  { bg: "bg-emerald-50", text: "text-emerald-700", subtle: "text-emerald-500", iconBg: "bg-emerald-100" },
    amber:  { bg: "bg-amber-50",   text: "text-amber-700",   subtle: "text-amber-500",   iconBg: "bg-amber-100"   },
    purple: { bg: "bg-violet-50",  text: "text-violet-700",  subtle: "text-violet-500",  iconBg: "bg-violet-100"  },
  }[color];
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{label}</p>
          <div className="flex items-baseline gap-1 mt-1.5">
            <span className={`text-2xl font-bold ${pal.text}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{value}</span>
            {unit && <span className="text-sm text-slate-400">{unit}</span>}
          </div>
          {sub && (
            <div className="flex items-center gap-1 mt-1">
              <ArrowUp className="w-3 h-3 text-emerald-500 flex-shrink-0" />
              <span className="text-xs text-emerald-600 font-semibold">{sub}</span>
            </div>
          )}
        </div>
        {Icon && (
          <div className={`w-10 h-10 ${pal.iconBg} rounded-xl flex items-center justify-center flex-shrink-0`}>
            <Icon className={`w-5 h-5 ${pal.subtle}`} />
          </div>
        )}
      </div>
    </Card>
  );
}

function CircleRing({ pct, size = 88, stroke = 9, color = "#1B5FA8" }: {
  pct: number; size?: number; stroke?: number; color?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#E2E8F0" strokeWidth={stroke} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke}
        strokeDasharray={`${pct/100*c} ${c}`} strokeLinecap="round"
        transform={`rotate(-90 ${size/2} ${size/2})`} />
    </svg>
  );
}

function SectionHead({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 mb-6">
      <div>
        <h2 className="text-xl font-bold text-slate-800" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{title}</h2>
        {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
      </div>
      {action && <div className="flex-shrink-0">{action}</div>}
    </div>
  );
}

function MiniSpark({ data, color = "#1B5FA8" }: { data: number[]; color?: string }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const w = 60, h = 24, n = data.length;
  const pts = data.map((v, i) => `${(i/(n-1))*w},${h - ((v-min)/range)*h}`).join(" ");
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ─── Screen: Patient Dashboard ────────────────────────────────────────────────

function PatientDashboard({ go }: { go: (s: string) => void }) {
  const [done, setDone] = useState<number[]>([1]);
  const toggle = (id: number) => setDone(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  return (
    <div className="space-y-6">
      {/* Welcome hero */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#1B5FA8] via-[#1554A0] to-[#0A8E81] p-6 text-white">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 80% 20%, #fff 0, transparent 60%)" }} />
        <div className="relative flex items-start justify-between flex-wrap gap-4">
          <div>
            <p className="text-blue-200 text-sm font-medium">Good morning</p>
            <h1 className="text-2xl font-bold mt-0.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Margaret Chen</h1>
            <p className="text-blue-200 text-sm mt-1">TKR Recovery · Week 6 of 12 · On Track</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-center bg-white/15 backdrop-blur rounded-xl px-4 py-3">
              <div className="text-2xl font-black" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>🔥 12</div>
              <div className="text-xs text-blue-200 mt-0.5">Day Streak</div>
            </div>
            <div className="text-center bg-white/15 backdrop-blur rounded-xl px-4 py-3">
              <div className="text-2xl font-black" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>⭐ 1,250</div>
              <div className="text-xs text-blue-200 mt-0.5">XP Earned</div>
            </div>
          </div>
        </div>
        <div className="relative mt-5">
          <div className="flex items-center justify-between text-xs text-blue-200 mb-1.5">
            <span>Overall Recovery Progress</span><span className="font-bold text-white">68%</span>
          </div>
          <div className="h-2 bg-white/20 rounded-full">
            <motion.div className="h-full bg-white rounded-full" initial={{ width: 0 }} animate={{ width: "68%" }} transition={{ duration: 1, ease: "easeOut", delay: 0.2 }} />
          </div>
          <div className="flex justify-between text-xs text-blue-300 mt-1">
            <span>Surgery</span><span>Full Recovery</span>
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatPill label="Knee Flexion"      value="95"  unit="°" sub="+8° this week" color="blue"  icon={Activity}   />
        <StatPill label="Extension Deficit" value="5"   unit="°" sub="Improving"     color="teal"  icon={Target}     />
        <StatPill label="Exercise Quality"  value="88"  unit="%" sub="+6% vs last"   color="green" icon={Shield}     />
        <StatPill label="Sessions Done"     value="18"  unit="/20"                   color="amber" icon={Calendar}   />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Daily Plan */}
        <div className="lg:col-span-3">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="font-bold text-slate-800" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{"Today's Plan"}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{done.length} of {dailyExercises.length} exercises completed</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-1.5 w-24 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-600 rounded-full transition-all duration-500" style={{ width: `${done.length/dailyExercises.length*100}%` }} />
                </div>
                <span className="text-xs font-bold text-blue-700">{Math.round(done.length/dailyExercises.length*100)}%</span>
              </div>
            </div>

            <div className="space-y-2.5">
              {dailyExercises.map((ex, idx) => {
                const completed = done.includes(ex.id);
                const inProgress = !completed && idx === done.length;
                return (
                  <motion.div key={ex.id} onClick={() => toggle(ex.id)} whileTap={{ scale: 0.985 }}
                    className={`flex items-center gap-4 p-3.5 rounded-xl cursor-pointer select-none transition-all ${completed ? "bg-emerald-50 border border-emerald-200" : inProgress ? "bg-blue-50 border-2 border-blue-300" : "bg-slate-50 border border-slate-100 hover:border-slate-200"}`}>
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${completed ? "bg-emerald-500 border-emerald-500" : inProgress ? "border-blue-400" : "border-slate-300"}`}>
                      {completed && <CheckCircle className="w-4 h-4 text-white" />}
                      {inProgress && <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className={`font-semibold text-sm ${completed ? "text-slate-400 line-through" : "text-slate-800"}`}>{ex.name}</div>
                      <div className="text-xs text-slate-500">{ex.sets} sets × {ex.reps} reps · {ex.duration} · {ex.muscle}</div>
                    </div>
                    {completed  && <Badge variant="success">Done</Badge>}
                    {inProgress && <Badge variant="info">Next</Badge>}
                  </motion.div>
                );
              })}
            </div>

            <div className="mt-5 pt-4 border-t border-slate-100">
              <button onClick={() => go("session")} className="w-full flex items-center justify-center gap-2 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-sm transition-colors">
                <Play className="w-4 h-4" /> Continue Rehabilitation Session
              </button>
            </div>
          </Card>
        </div>

        {/* Right column */}
        <div className="lg:col-span-2 space-y-4">
          {/* Recovery milestones */}
          <Card className="p-5">
            <h3 className="font-bold text-slate-800 mb-4 text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Recent Achievements</h3>
            <div className="space-y-2">
              {[
                { icon: "🏆", label: "Achieved 90° Flexion",  color: "bg-purple-50 text-purple-700" },
                { icon: "🔥", label: "12-Day Streak",          color: "bg-orange-50 text-orange-700" },
                { icon: "✅", label: "Week 6 Milestone",       color: "bg-emerald-50 text-emerald-700" },
                { icon: "⭐", label: "1,250 XP Earned",        color: "bg-yellow-50 text-yellow-700"  },
              ].map((a, i) => (
                <div key={i} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl ${a.color} text-sm font-semibold`}>
                  <span>{a.icon}</span>{a.label}
                </div>
              ))}
            </div>
          </Card>

          {/* Weekly challenge */}
          <Card className="p-5">
            <h3 className="font-bold text-slate-800 mb-3 text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Weekly Challenge</h3>
            <p className="text-xs text-slate-500 mb-3 leading-relaxed">Complete 5 sessions with average quality above 85%</p>
            <div className="space-y-2.5">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-500">Sessions</span><span className="font-bold text-blue-700">4 / 5</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full">
                  <div className="h-full bg-blue-600 rounded-full" style={{ width: "80%" }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-500">Avg Quality</span><span className="font-bold text-emerald-700">88% ✓</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: "88%" }} />
                </div>
              </div>
            </div>
            <div className="mt-3 text-xs text-slate-400">+75 XP on completion</div>
          </Card>
        </div>
      </div>

      {/* ROM Chart */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="font-bold text-slate-800" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Range of Motion Progress</h3>
            <p className="text-xs text-slate-400 mt-0.5">Last 10 rehabilitation sessions</p>
          </div>
          <Badge variant="info">+8° this week</Badge>
        </div>
        <div className="h-52">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={romHistory}>
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1B5FA8" stopOpacity={0.18} /><stop offset="95%" stopColor="#1B5FA8" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0A8E81" stopOpacity={0.18} /><stop offset="95%" stopColor="#0A8E81" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="session" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} unit="°" />
              <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E2E8F0", fontSize: 12, boxShadow: "0 4px 20px rgba(0,0,0,0.08)" }} />
              <Area type="monotone" dataKey="flexion"   stroke="#1B5FA8" fill="url(#g1)" strokeWidth={2.5} name="Flexion (°)" />
              <Area type="monotone" dataKey="extension" stroke="#0A8E81" fill="url(#g2)" strokeWidth={2.5} name="Extension Deficit (°)" />
              <Legend wrapperStyle={{ fontSize: 12, paddingTop: 12 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Start Session",  icon: Play,          screen: "session",       cls: "bg-blue-600 hover:bg-blue-700 text-white"    },
          { label: "My Progress",    icon: TrendingUp,    screen: "progress",      cls: "bg-teal-600 hover:bg-teal-700 text-white"    },
          { label: "Virtual Physio", icon: MessageCircle, screen: "virtual-physio",cls: "bg-indigo-600 hover:bg-indigo-700 text-white" },
          { label: "Achievements",   icon: Trophy,        screen: "achievements",  cls: "bg-amber-500 hover:bg-amber-600 text-white"  },
        ].map((a) => (
          <motion.button key={a.screen} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }} onClick={() => go(a.screen)}
            className={`flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl font-semibold text-sm transition-colors ${a.cls}`}>
            <a.icon className="w-4 h-4" />{a.label}
          </motion.button>
        ))}
      </div>
    </div>
  );
}

// ─── Screen: Live Exercise Session ────────────────────────────────────────────

function LiveExerciseSession() {
  const [formState, setFormState] = useState<"good" | "warn">("good");
  const [rep, setRep] = useState(7);

  return (
    <div className="space-y-5">
      <SectionHead title="Live Exercise Session" subtitle="Straight Leg Raise · Set 2 of 3 · Computer Vision Active" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Camera/CV view */}
        <div className="lg:col-span-2">
          <div className="relative rounded-2xl overflow-hidden bg-[#0B1220]" style={{ aspectRatio: "16/9" }}>
            {/* Grid overlay */}
            <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "linear-gradient(#4DF0FF 1px,transparent 1px),linear-gradient(90deg,#4DF0FF 1px,transparent 1px)", backgroundSize: "50px 50px" }} />
            {/* Scan line */}
            <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "repeating-linear-gradient(0deg,transparent,transparent 3px,#4DF0FF 3px,#4DF0FF 4px)" }} />

            {/* Skeleton SVG */}
            <svg viewBox="0 0 560 360" className="w-full h-full relative z-10" preserveAspectRatio="xMidYMid meet">
              {/* ── Skeleton bones (body, at rest) ── */}
              <g stroke="#38BDF8" strokeWidth="2.5" strokeLinecap="round" fill="none" opacity="0.75">
                {/* Spine */}
                <line x1="275" y1="95" x2="275" y2="120" />
                <line x1="275" y1="120" x2="275" y2="215" />
                {/* Shoulders */}
                <line x1="200" y1="120" x2="350" y2="120" />
                {/* Left arm */}
                <line x1="200" y1="120" x2="172" y2="180" />
                <line x1="172" y1="180" x2="160" y2="228" />
                {/* Right arm */}
                <line x1="350" y1="120" x2="378" y2="180" />
                <line x1="378" y1="180" x2="390" y2="228" />
                {/* Hips */}
                <line x1="235" y1="215" x2="315" y2="215" />
                {/* Right leg (standing/support) */}
                <line x1="315" y1="215" x2="322" y2="302" />
                <line x1="322" y1="302" x2="326" y2="345" />
              </g>

              {/* ── Left leg (raised — the exercise leg) ── */}
              <g stroke="#0EA5E9" strokeWidth="3.5" strokeLinecap="round">
                {/* Left thigh raised at ~30° */}
                <line x1="235" y1="215" x2="140" y2="254" />
                {/* Left shin (nearly fully extended — SLR) */}
                <line x1="140" y1="254" x2="62" y2="286" />
              </g>

              {/* ── Knee joint highlight (left knee at 140,254) ── */}
              <circle cx="140" cy="254" r="16" fill="#0EA5E9" fillOpacity="0.12" stroke="#0EA5E9" strokeWidth="1.5" strokeDasharray="5 4" />
              <circle cx="140" cy="254" r="8" fill="#0EA5E9" />
              <circle cx="140" cy="254" r="22" fill="none" stroke="#0EA5E9" strokeWidth="1" strokeDasharray="3 6" opacity="0.5" />

              {/* Angle arc */}
              <path d="M 162 244 A 28 28 0 0 0 136 274" stroke="#FBBF24" strokeWidth="2.5" fill="none" strokeLinecap="round" />
              <text x="170" y="252" fill="#FBBF24" fontSize="14" fontWeight="700" fontFamily="monospace">163°</text>

              {/* Hip joint highlight */}
              <circle cx="235" cy="215" r="7" fill="#60A5FA" />
              <circle cx="235" cy="215" r="13" fill="none" stroke="#60A5FA" strokeWidth="1" opacity="0.4" />

              {/* All joint dots (body at rest leg) */}
              <g fill="#38BDF8">
                <circle cx="275" cy="75" r="18" fill="none" stroke="#38BDF8" strokeWidth="2" />
                <circle cx="275" cy="95"  r="5.5" />
                <circle cx="200" cy="120" r="7" /><circle cx="350" cy="120" r="7" />
                <circle cx="172" cy="180" r="5" /><circle cx="378" cy="180" r="5" />
                <circle cx="160" cy="228" r="5" /><circle cx="390" cy="228" r="5" />
                <circle cx="315" cy="215" r="7" />
                <circle cx="322" cy="302" r="7" />
                <circle cx="326" cy="345" r="5" />
                <circle cx="62"  cy="286" r="5" />
              </g>

              {/* ── Overlays ── */}
              {/* Form status pill */}
              <rect x="14" y="14" width="148" height="36" rx="10" fill={formState === "good" ? "#10B981" : "#F59E0B"} fillOpacity="0.92" />
              <text x="26" y="37" fill="white" fontSize="13.5" fontWeight="700">{formState === "good" ? "✓  Good Form" : "⚠  Adjust Form"}</text>

              {/* LIVE badge */}
              <circle cx="497" cy="27" r="6" fill="#EF4444" />
              <text x="507" y="32" fill="#F1F5F9" fontSize="12" fontWeight="700" fontFamily="monospace">LIVE</text>

              {/* CV label */}
              <rect x="402" y="14" width="82" height="22" rx="7" fill="#0F172A" fillOpacity="0.8" />
              <text x="412" y="29" fill="#38BDF8" fontSize="10" fontWeight="700" fontFamily="monospace">CV ACTIVE</text>

              {/* Hip angle label */}
              <rect x="198" y="174" width="76" height="20" rx="5" fill="#0F172A" fillOpacity="0.75" />
              <text x="208" y="188" fill="#94A3B8" fontSize="10" fontFamily="monospace">Hip: 32°</text>
            </svg>

            {/* Bottom overlays */}
            <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between gap-3">
              <div className="bg-[#0B1220]/85 backdrop-blur-sm rounded-2xl px-5 py-3 border border-slate-700/60">
                <div className="text-slate-400 text-xs mb-0.5">Repetitions</div>
                <div className="flex items-baseline gap-1">
                  <span className="text-5xl font-black text-white leading-none" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{rep}</span>
                  <span className="text-slate-400 text-xl">/10</span>
                </div>
              </div>
              <div className="bg-[#0B1220]/85 backdrop-blur-sm rounded-2xl px-5 py-3 border border-slate-700/60 text-right">
                <div className="text-slate-400 text-xs mb-0.5">Exercise Quality</div>
                <div className="text-5xl font-black text-emerald-400 leading-none" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>88%</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right panel */}
        <div className="space-y-4">
          {/* Live feedback */}
          <Card className={`p-4 border-2 ${formState === "good" ? "border-emerald-300 bg-emerald-50" : "border-amber-300 bg-amber-50"}`}>
            <div className="flex items-center gap-2 mb-2.5">
              {formState === "good"
                ? <CheckCircle className="w-5 h-5 text-emerald-600" />
                : <AlertTriangle className="w-5 h-5 text-amber-600" />}
              <span className={`font-bold text-sm ${formState === "good" ? "text-emerald-800" : "text-amber-800"}`}>Live Feedback</span>
            </div>
            {formState === "good" ? (
              <p className="text-emerald-700 text-sm leading-relaxed">Excellent control. Maintain full knee extension and steady, controlled movement throughout the lift.</p>
            ) : (
              <div className="space-y-1.5 text-sm text-amber-700">
                <p className="flex items-start gap-2"><span>⚠</span>Straighten the knee slightly more</p>
                <p className="flex items-start gap-2"><span>⚠</span>Raise the leg 5–10 cm higher</p>
                <p className="flex items-start gap-2"><span>⚠</span>Slow down the lowering phase</p>
              </div>
            )}
          </Card>

          {/* Metrics */}
          <Card className="p-4">
            <h4 className="font-bold text-slate-800 mb-3 text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Live Metrics</h4>
            <div className="space-y-3">
              {[
                { label: "Knee Extension", value: "163°", ok: true  },
                { label: "Hold Duration",  value: "2.4 s", ok: true  },
                { label: "Mvt Control",    value: "91%",   ok: true  },
                { label: "ROM Score",      value: "96%",   ok: formState === "good" },
              ].map((m) => (
                <div key={m.label} className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">{m.label}</span>
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${m.ok ? "bg-emerald-500" : "bg-amber-500"}`} />
                    <span className="font-bold text-sm font-mono text-slate-800">{m.value}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Set progress */}
          <Card className="p-4">
            <h4 className="font-bold text-slate-800 mb-3 text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Set Progress</h4>
            <div className="space-y-2.5">
              {[
                { n: 1, done: true,  active: false, q: 91 },
                { n: 2, done: false, active: true,  q: 88 },
                { n: 3, done: false, active: false, q: null },
              ].map((s) => (
                <div key={s.n} className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold flex-shrink-0 ${s.done ? "bg-emerald-500 text-white" : s.active ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-400"}`}>
                    {s.done ? "✓" : s.n}
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-slate-700">Set {s.n}</div>
                    {s.q && <div className="text-xs text-slate-400">Quality: {s.q}%</div>}
                  </div>
                  {s.active && <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />}
                </div>
              ))}
            </div>
          </Card>

          <button onClick={() => setFormState(f => f === "good" ? "warn" : "good")}
            className="w-full py-2 text-xs text-slate-400 hover:text-slate-600 border border-dashed border-slate-200 rounded-xl transition-colors">
            Toggle feedback demo
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Screen: Virtual Physiotherapist ─────────────────────────────────────────

function VirtualPhysiotherapist() {
  const [msgs, setMsgs] = useState(chatHistory);
  const [input, setInput] = useState("");

  const send = () => {
    if (!input.trim()) return;
    setMsgs(p => [...p, { id: Date.now(), role: "user", type: "user", content: input }]);
    setInput("");
    setTimeout(() => {
      setMsgs(p => [...p, {
        id: Date.now() + 1, role: "ai", type: "physio",
        content: "Thank you for sharing that. Based on your recent session data, I recommend focusing on the hold duration at the top of each repetition. This will strengthen your quadriceps more effectively and accelerate recovery.",
      }]);
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <SectionHead title="Virtual Physiotherapist" subtitle="AI-powered rehabilitation coaching powered by your session data" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat interface */}
        <div className="lg:col-span-2">
          <Card className="flex flex-col" style={{ height: 580 }}>
            <div className="p-5 border-b border-slate-100 flex items-center gap-3">
              <div className="w-11 h-11 bg-gradient-to-br from-blue-600 to-teal-500 rounded-2xl flex items-center justify-center flex-shrink-0">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-bold text-slate-800" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Dr. RehabAI</div>
                <div className="text-xs text-emerald-600 flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                  Online · Reviewing Session 10
                </div>
              </div>
              <div className="ml-auto">
                <Badge variant="info">Personalised to your data</Badge>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {msgs.map((m) => (
                <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  {m.role !== "user" && (
                    <div className="w-7 h-7 bg-gradient-to-br from-blue-600 to-teal-500 rounded-full mr-2 flex-shrink-0 mt-0.5 flex items-center justify-center">
                      <Brain className="w-3.5 h-3.5 text-white" />
                    </div>
                  )}
                  <div className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                    m.role === "user"    ? "bg-blue-600 text-white rounded-br-sm" :
                    m.type === "insight" ? "bg-teal-50 text-teal-800 border border-teal-200 rounded-bl-sm" :
                    m.type === "tip"     ? "bg-amber-50 text-amber-800 border border-amber-200 rounded-bl-sm" :
                                           "bg-slate-100 text-slate-700 rounded-bl-sm"
                  }`}>
                    {m.type === "insight" && <div className="text-xs font-bold text-teal-600 mb-1.5 uppercase tracking-wider">📊 Progress Insight</div>}
                    {m.type === "tip"     && <div className="text-xs font-bold text-amber-600 mb-1.5 uppercase tracking-wider">💡 Technique Tip</div>}
                    {m.content}
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 border-t border-slate-100">
              <div className="flex gap-2">
                <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()}
                  placeholder="Ask about your recovery, exercises, or progress..."
                  className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" />
                <button onClick={send} className="p-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors">
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </Card>
        </div>

        {/* Session summary panel */}
        <div className="space-y-4">
          <Card className="p-5">
            <h4 className="font-bold text-slate-800 mb-4 text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Session 10 Quality</h4>
            <div className="flex items-center justify-center mb-5">
              <div className="relative">
                <CircleRing pct={88} size={104} stroke={10} color="#10B981" />
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-black text-emerald-600" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>88%</span>
                  <span className="text-xs text-slate-400">Quality</span>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              {[
                { label: "ROM Achievement",  n: 40, d: 40, color: "bg-blue-500"    },
                { label: "Movement Control", n: 23, d: 25, color: "bg-teal-500"    },
                { label: "Form Assessment",  n: 17, d: 20, color: "bg-indigo-500"  },
                { label: "Hold Duration",    n: 13, d: 15, color: "bg-emerald-500" },
              ].map((s) => (
                <div key={s.label}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-600">{s.label}</span>
                    <span className="font-bold text-slate-700">{s.n}/{s.d}</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full">
                    <div className={`h-full ${s.color} rounded-full`} style={{ width: `${s.n/s.d*100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <h4 className="font-bold text-slate-800 mb-3 text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Recommended Next Steps</h4>
            <div className="space-y-2.5">
              {[
                "Increase Heel Slides to 4 sets from next session",
                "Hold at peak extension for 3 seconds",
                "Introduce Quad Sets in Week 7",
                "Schedule check-in with Dr. Patel",
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <div className="w-5 h-5 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-blue-700 text-xs font-bold">{i+1}</span>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">{step}</p>
                </div>
              ))}
            </div>
          </Card>

          <div className="rounded-2xl bg-gradient-to-br from-blue-700 to-teal-600 p-5 text-white">
            <h4 className="font-bold mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Overall Assessment</h4>
            <p className="text-sm text-blue-100 leading-relaxed">Excellent progress this week. Movement control has improved significantly and you are firmly on track for the 12-week recovery target.</p>
            <div className="mt-3 flex gap-2">
              <span className="px-2.5 py-1 bg-white/20 rounded-lg text-xs font-bold">Improving ↑</span>
              <span className="px-2.5 py-1 bg-white/20 rounded-lg text-xs font-bold">Excellent Quality</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Screen: Recovery Progress ────────────────────────────────────────────────

function RecoveryProgress() {
  const [tab, setTab] = useState<"rom"|"quality"|"adherence">("rom");
  const intensities = ["bg-slate-100","bg-blue-100","bg-blue-300","bg-blue-500","bg-blue-700"];

  return (
    <div className="space-y-6">
      <SectionHead title="Recovery Progress" subtitle="Comprehensive rehabilitation outcome analytics across all sessions" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Sessions Done",   value: "18", unit: "/ 20",  color: "blue"  as const, icon: Calendar  },
          { label: "Avg Quality",     value: "87", unit: "%",     color: "green" as const, icon: Shield    },
          { label: "Active Streak",   value: "12", unit: "days",  color: "amber" as const, icon: Flame     },
          { label: "Weeks Complete",  value: "6",  unit: "/ 12",  color: "teal"  as const, icon: Activity  },
        ].map((s) => <StatPill key={s.label} {...s} />)}
      </div>

      {/* Tabbed charts */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-5 flex-wrap">
          {[
            { key: "rom",       label: "Range of Motion"   },
            { key: "quality",   label: "Exercise Quality"  },
            { key: "adherence", label: "Session Adherence" },
          ].map(t => (
            <button key={t.key} onClick={() => setTab(t.key as typeof tab)}
              className={`px-4 py-1.5 rounded-xl text-sm font-semibold transition-all ${tab === t.key ? "bg-blue-600 text-white shadow-sm" : "text-slate-500 hover:bg-slate-100"}`}>
              {t.label}
            </button>
          ))}
        </div>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            {tab === "rom" ? (
              <LineChart data={romHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="session" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} unit="°" />
                <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E2E8F0", fontSize: 12, boxShadow: "0 4px 20px rgba(0,0,0,0.08)" }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" dataKey="flexion"   stroke="#1B5FA8" strokeWidth={2.5} dot={{ r: 3.5, fill: "#1B5FA8" }} name="Flexion (°)" />
                <Line type="monotone" dataKey="extension" stroke="#0A8E81" strokeWidth={2.5} dot={{ r: 3.5, fill: "#0A8E81" }} name="Extension Deficit (°)" />
              </LineChart>
            ) : tab === "quality" ? (
              <AreaChart data={romHistory}>
                <defs><linearGradient id="qg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#10B981" stopOpacity={0.22} /><stop offset="95%" stopColor="#10B981" stopOpacity={0} /></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="session" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} unit="%" domain={[65, 95]} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E2E8F0", fontSize: 12 }} />
                <ReferenceLine y={85} stroke="#F59E0B" strokeDasharray="4 3" strokeWidth={1.5} label={{ value: "Target", fill: "#F59E0B", fontSize: 11 }} />
                <Area type="monotone" dataKey="quality" stroke="#10B981" fill="url(#qg)" strokeWidth={2.5} name="Quality Score (%)" />
              </AreaChart>
            ) : (
              <BarChart data={adherenceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="week" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E2E8F0", fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="completed" fill="#1B5FA8" name="Sessions Completed" radius={[5,5,0,0]} />
                <Bar dataKey="target"    fill="#E2E8F0" name="Target"             radius={[5,5,0,0]} />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* History */}
        <Card className="p-5">
          <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Session History</h4>
          <div className="space-y-0">
            {[
              { s: "Session 10", date: "Today",       flex: 95, ext: 5,  q: 88, label: "Excellent" },
              { s: "Session 9",  date: "2 days ago",  flex: 92, ext: 7,  q: 86, label: "Excellent" },
              { s: "Session 8",  date: "4 days ago",  flex: 89, ext: 8,  q: 85, label: "Good"      },
              { s: "Session 7",  date: "6 days ago",  flex: 85, ext: 10, q: 83, label: "Good"      },
              { s: "Session 6",  date: "8 days ago",  flex: 79, ext: 12, q: 81, label: "Good"      },
            ].map((row, i) => (
              <div key={i} className="flex items-center justify-between py-3 border-b border-slate-50 last:border-0">
                <div>
                  <div className="text-sm font-semibold text-slate-700">{row.s}</div>
                  <div className="text-xs text-slate-400">{row.date}</div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <div className="text-xs text-slate-400">Flex</div>
                    <div className="text-sm font-bold text-blue-700 font-mono">{row.flex}°</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xs text-slate-400">Ext</div>
                    <div className="text-sm font-bold text-teal-700 font-mono">{row.ext}°</div>
                  </div>
                  <Badge variant={row.q >= 85 ? "success" : "info"}>{row.label}</Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Calendar heatmap */}
        <Card className="p-5">
          <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Adherence Calendar</h4>
          <div className="grid grid-cols-7 gap-1.5">
            {["M","T","W","T","F","S","S"].map((d, i) => (
              <div key={i} className="text-center text-xs text-slate-400 font-semibold pb-1">{d}</div>
            ))}
            {heatmap.map((v, i) => (
              <div key={i} className={`rounded-lg aspect-square ${intensities[v]} transition-opacity hover:opacity-70 cursor-pointer`} title={v === 0 ? "No session" : ["","Light","Moderate","Good","Excellent"][v]} />
            ))}
          </div>
          <div className="flex items-center justify-between mt-3 text-xs text-slate-400">
            <span>Less active</span>
            <div className="flex gap-1">{intensities.map((c,i) => <div key={i} className={`w-3.5 h-3.5 rounded ${c}`} />)}</div>
            <span>More active</span>
          </div>
        </Card>
      </div>

      {/* Milestones */}
      <Card className="p-5">
        <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Recovery Milestones</h4>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          {[
            { label: "First Session Completed",    done: true,  info: "Achieved · Week 1",    icon: "🚀" },
            { label: "7-Day Streak Achieved",      done: true,  info: "Achieved · Week 2",    icon: "🔥" },
            { label: "90° Flexion Achieved",       done: true,  info: "Achieved · Week 4",    icon: "📐" },
            { label: "Full Knee Extension (0°)",   done: false, info: "Target: Week 8",        icon: "🎯" },
            { label: "Return to Stairs",           done: false, info: "Target: Week 8",        icon: "🏃" },
            { label: "Return to Daily Activities", done: false, info: "Target: Week 10",       icon: "🏠" },
          ].map((m, i) => (
            <div key={i} className={`flex items-center gap-3 p-4 rounded-xl ${m.done ? "bg-emerald-50 border border-emerald-200" : "bg-slate-50 border border-slate-100"}`}>
              <div className="text-2xl">{m.icon}</div>
              <div>
                <div className={`text-sm font-bold ${m.done ? "text-emerald-800" : "text-slate-600"}`}>{m.label}</div>
                <div className="text-xs text-slate-400 mt-0.5">{m.info}</div>
              </div>
              {m.done && <CheckCircle className="w-5 h-5 text-emerald-500 ml-auto flex-shrink-0" />}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ─── Screen: Achievements ─────────────────────────────────────────────────────

function AchievementsScreen() {
  return (
    <div className="space-y-6">
      <SectionHead title="Recovery Journey" subtitle="Gamified rehabilitation progress and milestones" />

      {/* Hero progress */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-700 via-blue-800 to-teal-700 p-7 text-white">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 90% 10%, #fff 0, transparent 50%)" }} />
        <div className="relative flex items-start justify-between flex-wrap gap-5">
          <div>
            <p className="text-blue-200 text-xs font-bold uppercase tracking-wider">Overall Recovery Progress</p>
            <div className="text-7xl font-black mt-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>68%</div>
            <p className="text-blue-200 mt-1 text-sm">Week 6 of 12 · On Track for Full Recovery</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: "🔥", val: "12", label: "Day Streak" },
              { icon: "⭐", val: "1,250", label: "XP Earned" },
              { icon: "🏆", val: "4",   label: "Milestones" },
              { icon: "📈", val: "88%", label: "Avg Quality" },
            ].map((s) => (
              <div key={s.label} className="bg-white/15 backdrop-blur rounded-xl px-4 py-3 text-center">
                <div className="text-lg font-black">{s.icon} {s.val}</div>
                <div className="text-blue-200 text-xs mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="relative mt-6">
          <div className="flex justify-between text-xs text-blue-200 mb-1.5">
            <span>Surgery / Injury</span><span className="font-bold text-white">68% Complete</span><span>Full Recovery</span>
          </div>
          <div className="h-3 bg-white/20 rounded-full overflow-hidden">
            <motion.div className="h-full bg-white rounded-full" initial={{ width: 0 }} animate={{ width: "68%" }} transition={{ duration: 1.2, ease: "easeOut", delay: 0.3 }} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* XP breakdown */}
        <Card className="p-5">
          <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>XP System</h4>
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-3xl font-black text-yellow-600" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>1,250</div>
              <div className="text-xs text-slate-400">Total XP · +150 this week</div>
            </div>
            <Star className="w-10 h-10 text-yellow-400" />
          </div>
          <div className="space-y-2 text-sm">
            {[
              { source: "Exercise Completion",  xp: "+50 XP per session" },
              { source: "Good Form Bonus",      xp: "+25 XP above 85%"  },
              { source: "Weekly Challenge",     xp: "+75 XP on complete" },
              { source: "Milestone Achieved",   xp: "+100 XP per badge"  },
            ].map((s) => (
              <div key={s.source} className="flex items-center justify-between py-1.5 border-b border-slate-50 last:border-0">
                <span className="text-slate-600">{s.source}</span>
                <span className="font-bold text-yellow-600 text-xs">{s.xp}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 h-2 bg-yellow-100 rounded-full">
            <div className="h-full bg-yellow-400 rounded-full" style={{ width: "63%" }} />
          </div>
          <div className="text-xs text-slate-400 mt-1">750 XP to next level</div>
        </Card>

        {/* Weekly challenges */}
        <Card className="p-5">
          <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Weekly Challenges</h4>
          <div className="space-y-4">
            {[
              { title: "Complete 5 Sessions",         cur: 4,  max: 5,  xp: 75,  done: false },
              { title: "Maintain Quality Above 85%",  cur: 88, max: 85, xp: 50,  done: true  },
              { title: "10 Perfect Form Reps",        cur: 7,  max: 10, xp: 40,  done: false },
            ].map((c, i) => (
              <div key={i} className={`p-3.5 rounded-xl border ${c.done ? "bg-emerald-50 border-emerald-200" : "bg-slate-50 border-slate-100"}`}>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="text-sm font-bold text-slate-800">{c.title}</div>
                    <div className="text-xs text-slate-400 mt-0.5">+{c.xp} XP on completion</div>
                  </div>
                  {c.done
                    ? <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                    : <Target className="w-5 h-5 text-slate-300 flex-shrink-0" />}
                </div>
                <div className="flex justify-between text-xs text-slate-500 mb-1.5">
                  <span>Progress</span><span className="font-bold">{Math.min(c.cur, c.max)} / {c.max}</span>
                </div>
                <div className="h-2 bg-slate-200 rounded-full">
                  <div className={`h-full rounded-full ${c.done ? "bg-emerald-500" : "bg-blue-500"}`} style={{ width: `${Math.min(c.cur/c.max*100,100)}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Badges */}
        <Card className="p-5">
          <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Achievement Badges</h4>
          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: "🚀", label: "First Steps",        desc: "Completed Session 1",  earned: true  },
              { icon: "🔥", label: "Week Warrior",        desc: "7-Day Streak",         earned: true  },
              { icon: "📐", label: "Flex Master",         desc: "Achieved 90° Flexion", earned: true  },
              { icon: "✨", label: "Form Expert",         desc: "90%+ Quality Session", earned: true  },
              { icon: "🎯", label: "Full Extension",      desc: "0° Deficit Achieved",  earned: false },
              { icon: "🏆", label: "Recovery Champion",   desc: "100% Programme Done",  earned: false },
            ].map((b, i) => (
              <motion.div key={i} whileHover={b.earned ? { scale: 1.04 } : {}}
                className={`p-3.5 rounded-xl border text-center transition-all ${b.earned ? "bg-blue-50 border-blue-200 cursor-pointer" : "bg-slate-50 border-slate-100 opacity-40"}`}>
                <div className="text-2xl mb-1.5">{b.icon}</div>
                <div className="text-xs font-bold text-slate-800">{b.label}</div>
                <div className="text-xs text-slate-500 mt-0.5">{b.desc}</div>
              </motion.div>
            ))}
          </div>
        </Card>
      </div>

      {/* Timeline */}
      <Card className="p-6">
        <h4 className="font-bold text-slate-800 mb-6" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Recovery Timeline</h4>
        <div className="relative">
          <div className="absolute top-4 left-0 right-0 h-0.5 bg-slate-200" />
          <div className="absolute top-4 left-0 h-0.5 bg-blue-600" style={{ width: "50%" }} />
          <div className="grid grid-cols-4 relative">
            {[
              { label: "Week 1–2", desc: "Basic mobility",    done: true,  current: false },
              { label: "Week 3–4", desc: "Strength building", done: true,  current: false },
              { label: "Week 5–8", desc: "Full ROM target",   done: false, current: true  },
              { label: "Wk 9–12", desc: "Return to activity", done: false, current: false },
            ].map((w, i) => (
              <div key={i} className="flex flex-col items-center text-center">
                <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center mb-2.5 bg-white z-10 transition-all ${w.done ? "border-blue-600 bg-blue-600" : w.current ? "border-blue-600 shadow-md shadow-blue-200" : "border-slate-300"}`}>
                  {w.done    && <CheckCircle className="w-4 h-4 text-white" />}
                  {w.current && <div className="w-3 h-3 rounded-full bg-blue-600" />}
                </div>
                <div className={`text-xs font-bold ${w.current ? "text-blue-700" : "text-slate-600"}`}>{w.label}</div>
                <div className="text-xs text-slate-400 mt-0.5">{w.desc}</div>
                {w.current && <span className="mt-2 inline-block px-2 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-700">Current</span>}
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

// ─── Screen: Patient Overview (Physio) ────────────────────────────────────────

function PatientOverview({ go }: { go: (s: string) => void }) {
  const statusCfg: Record<string, { border: string; badge: BadgeVariant; label: string; dot: string }> = {
    improving: { border: "border-l-emerald-500", badge: "success", label: "Improving",      dot: "bg-emerald-500" },
    stable:    { border: "border-l-blue-400",    badge: "info",    label: "Stable",          dot: "bg-blue-400"   },
    attention: { border: "border-l-amber-500",   badge: "warning", label: "Needs Attention", dot: "bg-amber-500"  },
  };

  const flexionData = (base: number) => Array.from({ length: 6 }, (_, i) => base - 15 + i * 3);

  return (
    <div className="space-y-6">
      <SectionHead title="Patient Overview" subtitle="6 active patients across your caseload"
        action={
          <div className="flex gap-2">
            <span className="px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-700 flex items-center gap-1.5"><div className="w-2 h-2 bg-emerald-500 rounded-full" />4 Improving</span>
            <span className="px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-xl text-xs font-bold text-amber-700 flex items-center gap-1.5"><AlertTriangle className="w-3 h-3" />2 Attention</span>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {patients.map((p) => {
          const s = statusCfg[p.status];
          return (
            <Card key={p.id} className={`p-5 border-l-4 ${s.border} hover:shadow-md transition-shadow`}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 bg-gradient-to-br from-blue-500 to-teal-400 rounded-2xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                    {p.initials}
                  </div>
                  <div>
                    <div className="font-bold text-slate-800" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{p.name}</div>
                    <div className="text-xs text-slate-500">{p.age}y · {p.condition} · {p.stage}</div>
                  </div>
                </div>
                <Badge variant={s.badge}>{s.label}</Badge>
              </div>

              <div className="grid grid-cols-4 gap-2 mb-4">
                <div className="col-span-1 text-center p-2.5 bg-blue-50 rounded-xl">
                  <div className="text-lg font-black text-blue-700 font-mono" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{p.flexion}°</div>
                  <div className="text-xs text-slate-400 mt-0.5">Flex</div>
                </div>
                <div className="col-span-1 text-center p-2.5 bg-teal-50 rounded-xl">
                  <div className="text-lg font-black text-teal-700 font-mono" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{p.extension}°</div>
                  <div className="text-xs text-slate-400 mt-0.5">Ext Def</div>
                </div>
                <div className="col-span-1 text-center p-2.5 bg-indigo-50 rounded-xl">
                  <div className="text-lg font-black text-indigo-700" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{p.compliance}%</div>
                  <div className="text-xs text-slate-400 mt-0.5">Compl</div>
                </div>
                <div className="col-span-1 flex flex-col items-center justify-center p-2 bg-slate-50 rounded-xl">
                  <MiniSpark data={flexionData(p.flexion)} color={p.status === "improving" ? "#10B981" : "#F59E0B"} />
                  <div className="text-xs text-slate-400 mt-1">{p.trend}/wk</div>
                </div>
              </div>

              <div className="mb-3">
                <div className="flex justify-between text-xs text-slate-500 mb-1">
                  <span>Compliance</span><span className="font-bold text-slate-700">{p.compliance}%</span>
                </div>
                <div className="h-1.5 bg-slate-100 rounded-full">
                  <div className={`h-full rounded-full ${p.compliance >= 80 ? "bg-emerald-500" : p.compliance >= 60 ? "bg-amber-500" : "bg-red-500"}`} style={{ width: `${p.compliance}%` }} />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Last active: {p.last}</span>
                <div className="flex gap-2">
                  {p.status === "attention" && (
                    <button className="px-3 py-1.5 bg-amber-100 text-amber-700 border border-amber-200 rounded-xl text-xs font-bold hover:bg-amber-200 transition-colors">Review</button>
                  )}
                  <button onClick={() => go("prescription")} className="px-3 py-1.5 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors">Manage</button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

// ─── Screen: Exercise Prescription ───────────────────────────────────────────

function ExercisePrescription() {
  const [sel, setSel] = useState(1);
  const [pres, setPres] = useState([
    { id: 1, name: "Straight Leg Raise",      sets: 3, reps: 10, freq: "Daily",   active: true  },
    { id: 2, name: "Heel Slides",             sets: 3, reps: 15, freq: "Daily",   active: true  },
    { id: 3, name: "Seated Knee Extension",   sets: 3, reps: 12, freq: "Daily",   active: true  },
    { id: 4, name: "Terminal Knee Extension", sets: 3, reps: 12, freq: "5×/week", active: true  },
    { id: 5, name: "Wall Slides",             sets: 2, reps: 10, freq: "3×/week", active: false },
  ]);
  const toggle = (id: number) => setPres(p => p.map(e => e.id === id ? { ...e, active: !e.active } : e));
  const save = () => toast.success("Programme saved and sent to patient");

  return (
    <div className="space-y-6">
      <SectionHead title="Exercise Prescription" subtitle="Assign and modify patient rehabilitation programmes" />

      <Card className="p-4">
        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 block">Selected Patient</label>
        <div className="flex gap-2 flex-wrap">
          {patients.map(p => (
            <button key={p.id} onClick={() => setSel(p.id)}
              className={`px-3 py-1.5 rounded-xl text-sm font-semibold transition-all ${sel === p.id ? "bg-blue-600 text-white shadow-sm" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}>
              {p.name.split(" ")[0]} {p.name.split(" ")[1][0]}.
            </button>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-bold text-slate-800" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Prescribed Exercises</h4>
              <button onClick={() => toast.info("Exercise picker coming soon")} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-colors">
                <Plus className="w-4 h-4" /> Add Exercise
              </button>
            </div>
            <div className="space-y-2.5">
              {pres.map((ex) => (
                <div key={ex.id} className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${ex.active ? "border-slate-200 bg-white" : "border-slate-100 bg-slate-50 opacity-50"}`}>
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${ex.active ? "bg-blue-100 text-blue-600" : "bg-slate-200 text-slate-400"}`}>
                    <Activity className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm text-slate-800">{ex.name}</div>
                    <div className="text-xs text-slate-500">{ex.sets} sets × {ex.reps} reps · {ex.freq}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => toggle(ex.id)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${ex.active ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-200" : "bg-slate-200 text-slate-500 hover:bg-slate-300"}`}>
                      {ex.active ? "Active" : "Paused"}
                    </button>
                    <button onClick={() => toast.info(`Editing ${ex.name}`)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                      <Edit3 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5">
            <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Rehabilitation Goals</h4>
            <div className="space-y-3.5">
              {[
                { label: "Target Flexion",         default: 120, suffix: "°" },
                { label: "Extension Deficit Goal", default: 0,   suffix: "°" },
                { label: "Weekly Session Target",  default: 5   },
              ].map((f) => (
                <div key={f.label}>
                  <label className="text-xs text-slate-500 font-semibold block mb-1">{f.label}</label>
                  <div className="flex items-center gap-2">
                    <input type="number" defaultValue={f.default}
                      className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50" />
                    {f.suffix && <span className="text-sm text-slate-400 flex-shrink-0">{f.suffix}</span>}
                  </div>
                </div>
              ))}
              <div>
                <label className="text-xs text-slate-500 font-semibold block mb-1">Programme Duration</label>
                <select className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50">
                  <option>12 weeks</option><option>8 weeks</option><option>16 weeks</option>
                </select>
              </div>
            </div>
          </Card>

          <Card className="p-5">
            <h4 className="font-bold text-slate-800 mb-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Clinical Notes</h4>
            <textarea rows={5}
              className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none bg-slate-50 text-slate-700 leading-relaxed"
              defaultValue="Patient progressing well. Increase SLR intensity from Week 7. Monitor patellofemoral response — reduce load if pain reported above 3/10." />
            <button onClick={save} className="mt-3 w-full py-3 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-colors">
              Save Programme
            </button>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ─── Screen: Monitor Progress (Physio) ───────────────────────────────────────

function MonitorProgress() {
  const [sel, setSel] = useState(1);
  const patient = patients.find(p => p.id === sel)!;

  const alerts = patient.compliance < 70 ? [
    { type: "warning" as const, msg: "Compliance below 70% — consider a check-in call" },
    { type: "warning" as const, msg: "3 consecutive missed sessions detected" },
  ] : [
    { type: "success" as const, msg: "Patient maintaining above 80% compliance consistently" },
    { type: "success" as const, msg: "Consistent quality improvement over past 3 weeks" },
    { type: "info"    as const, msg: "Approaching next milestone — consider advancing programme" },
  ];

  return (
    <div className="space-y-6">
      <SectionHead title="Monitor Progress" subtitle="Detailed rehabilitation analytics for individual patients" />

      <div className="flex gap-2 flex-wrap">
        {patients.map(p => (
          <button key={p.id} onClick={() => setSel(p.id)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-semibold transition-all ${sel === p.id ? "bg-blue-600 text-white shadow-sm" : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
            {p.status === "attention" && <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />}
            {p.name.split(" ")[0]}
          </button>
        ))}
      </div>

      <Card className="p-5 flex items-center gap-5 flex-wrap">
        <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-teal-400 rounded-2xl flex items-center justify-center text-white font-black text-lg flex-shrink-0" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
          {patient.initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-black text-slate-800 text-xl" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{patient.name}</div>
          <div className="text-sm text-slate-500">{patient.condition} · {patient.stage} · Last active {patient.last}</div>
        </div>
        <div className="flex gap-4">
          {[
            { v: `${patient.flexion}°`,    label: "Flexion",    cls: "text-blue-700"   },
            { v: `${patient.extension}°`,  label: "Ext Deficit", cls: "text-teal-700"  },
            { v: `${patient.compliance}%`, label: "Compliance",  cls: "text-indigo-700" },
          ].map(s => (
            <div key={s.label} className="text-center">
              <div className={`text-2xl font-black font-mono ${s.cls}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{s.v}</div>
              <div className="text-xs text-slate-400 mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-5">
          <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Flexion ROM Trend</h4>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={romHistory}>
                <defs><linearGradient id="mfg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#1B5FA8" stopOpacity={0.2} /><stop offset="95%" stopColor="#1B5FA8" stopOpacity={0} /></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="session" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} unit="°" />
                <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E2E8F0", fontSize: 12 }} />
                <Area type="monotone" dataKey="flexion" stroke="#1B5FA8" fill="url(#mfg)" strokeWidth={2.5} name="Flexion (°)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Exercise Quality Trend</h4>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={romHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="session" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} unit="%" domain={[65, 95]} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E2E8F0", fontSize: 12 }} />
                <ReferenceLine y={85} stroke="#F59E0B" strokeDasharray="4 3" />
                <Line type="monotone" dataKey="quality" stroke="#10B981" strokeWidth={2.5} dot={{ r: 3.5, fill: "#10B981" }} name="Quality (%)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Session Adherence</h4>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={adherenceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="week" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid #E2E8F0", fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="completed" fill="#6366F1" name="Sessions" radius={[5,5,0,0]} />
                <Bar dataKey="target"    fill="#E2E8F0" name="Target"   radius={[5,5,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Clinical Alerts</h4>
          <div className="space-y-3">
            {alerts.map((a, i) => (
              <div key={i} className={`flex items-start gap-2.5 p-3.5 rounded-xl ${
                a.type === "warning" ? "bg-amber-50 border border-amber-200" :
                a.type === "success" ? "bg-emerald-50 border border-emerald-200" :
                                       "bg-blue-50 border border-blue-200"
              }`}>
                {a.type === "warning" ? <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  : a.type === "success" ? <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                  : <Activity className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />}
                <p className="text-sm text-slate-700 leading-relaxed">{a.msg}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ─── Screen: Review Adherence ─────────────────────────────────────────────────

function ReviewAdherence() {
  const remind = (name: string) => toast.success(`Reminder sent to ${name}`);
  const followUp = (name: string) => toast.success(`Follow-up scheduled for ${name}`);

  return (
    <div className="space-y-6">
      <SectionHead title="Adherence Review" subtitle="Monitor engagement and compliance across your full caseload" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Sessions Completed", value: "18",    unit: "/ 20",  icon: CheckSquare,   color: "blue"  as const },
          { label: "Average Quality",    value: "87",    unit: "%",     icon: Star,          color: "green" as const },
          { label: "Avg Active Streak",  value: "8.5",   unit: "days",  icon: Flame,         color: "amber" as const },
          { label: "At-Risk Patients",   value: "2",     unit: "",      icon: AlertTriangle, color: "teal"  as const },
        ].map(s => <StatPill key={s.label} {...s} />)}
      </div>

      <Card className="p-5 overflow-x-auto">
        <h4 className="font-bold text-slate-800 mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Patient Adherence Overview</h4>
        <table className="w-full text-sm min-w-[680px]">
          <thead>
            <tr className="border-b border-slate-100">
              {["Patient","Condition","Stage","Quality","Streak","Compliance","Status","Action"].map(h => (
                <th key={h} className="text-left text-xs font-bold text-slate-400 uppercase tracking-wider pb-3 pr-4 whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {patients.map(p => (
              <tr key={p.id} className={`border-b border-slate-50 ${p.status === "attention" ? "bg-amber-50/40" : ""}`}>
                <td className="py-3 pr-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-teal-400 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0">{p.initials}</div>
                    <span className="font-bold text-slate-800 whitespace-nowrap">{p.name}</span>
                  </div>
                </td>
                <td className="py-3 pr-4 text-slate-500 text-xs whitespace-nowrap">{p.condition}</td>
                <td className="py-3 pr-4 text-slate-500 text-xs">{p.stage}</td>
                <td className="py-3 pr-4 font-bold text-slate-700">{Math.floor(70 + p.compliance*0.18)}%</td>
                <td className="py-3 pr-4 font-bold text-slate-700">{Math.floor(p.compliance/10)} d</td>
                <td className="py-3 pr-4">
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 bg-slate-100 rounded-full">
                      <div className={`h-full rounded-full ${p.compliance>=80?"bg-emerald-500":p.compliance>=60?"bg-amber-500":"bg-red-500"}`} style={{ width: `${p.compliance}%` }} />
                    </div>
                    <span className="text-xs font-bold text-slate-600">{p.compliance}%</span>
                  </div>
                </td>
                <td className="py-3 pr-4">
                  <Badge variant={p.status==="improving"?"success":p.status==="stable"?"info":"warning"}>
                    {p.status==="improving"?"Improving":p.status==="stable"?"Stable":"Attention"}
                  </Badge>
                </td>
                <td className="py-3">
                  {p.status==="attention"
                    ? <button onClick={() => remind(p.name.split(" ")[0])} className="px-2.5 py-1 bg-amber-600 text-white rounded-lg text-xs font-bold hover:bg-amber-700 transition-colors">Follow Up</button>
                    : <button className="px-2.5 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-bold hover:bg-slate-200 transition-colors">View</button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <div className="rounded-2xl bg-amber-50 border border-amber-200 p-5">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
          <h4 className="font-bold text-amber-800" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Patients Requiring Attention</h4>
        </div>
        <div className="space-y-3">
          {patients.filter(p => p.status === "attention").map(p => (
            <div key={p.id} className="bg-white rounded-2xl p-4 border border-amber-200 flex items-center justify-between flex-wrap gap-3">
              <div>
                <div className="font-bold text-slate-800">{p.name}</div>
                <div className="text-sm text-slate-500">Compliance: {p.compliance}% · Last session: {p.last} · {p.condition}</div>
              </div>
              <div className="flex gap-2 flex-wrap">
                <button onClick={() => remind(p.name.split(" ")[0])} className="px-3 py-1.5 bg-white border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors">Send Reminder</button>
                <button onClick={() => followUp(p.name.split(" ")[0])} className="px-3 py-1.5 bg-amber-600 text-white rounded-xl text-xs font-bold hover:bg-amber-700 transition-colors">Schedule Follow-Up</button>
                <button onClick={() => toast.info("Programme modification tool opening")} className="px-3 py-1.5 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors">Modify Programme</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Screen: System Architecture ─────────────────────────────────────────────

function ArchitectureScreen() {
  const pipeline = [
    { icon: "📷", label: "Camera / Sensor",                sub: "Standard RGB or depth camera — no markers required", color: "from-slate-800 to-slate-700" },
    { icon: "🧠", label: "Markerless Computer Vision",      sub: "MediaPipe Pose · OpenCV · 33-point skeletal tracking", color: "from-blue-900 to-blue-700" },
    { icon: "📐", label: "Joint Angle Extraction",          sub: "Real-time knee, hip, and ankle angle computation",    color: "from-blue-700 to-blue-600" },
    { icon: "⚡", label: "Virtual Physiotherapist Engine",  sub: "Evidence-based feedback AI · < 50 ms latency",        color: "from-teal-800 to-teal-700" },
    { icon: "✅", label: "Exercise Quality Assessment",     sub: "ROM (40%) · Control (25%) · Form (20%) · Hold (15%)", color: "from-teal-700 to-teal-600" },
    { icon: "📈", label: "Recovery Progress Tracking",      sub: "Session analytics, outcome trends, and reporting",    color: "from-indigo-700 to-indigo-600" },
  ];

  return (
    <div className="space-y-6">
      <SectionHead title="System Architecture" subtitle="How Smart Knee Rehabilitation Assistant processes motion and delivers clinical intelligence" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pipeline */}
        <Card className="p-6">
          <h4 className="font-bold text-slate-800 mb-5 text-center" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Processing Pipeline</h4>
          <div className="space-y-1.5">
            {pipeline.map((node, i) => (
              <div key={node.label}>
                <div className={`bg-gradient-to-r ${node.color} rounded-2xl p-4 flex items-center gap-4 text-white shadow-sm`}>
                  <span className="text-2xl flex-shrink-0">{node.icon}</span>
                  <div>
                    <div className="font-bold text-sm leading-tight" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{node.label}</div>
                    <div className="text-xs opacity-70 mt-0.5">{node.sub}</div>
                  </div>
                </div>
                {i < pipeline.length - 1 && (
                  <div className="flex justify-center py-1">
                    <ChevronDown className="w-4 h-4 text-slate-300" />
                  </div>
                )}
              </div>
            ))}
            <div className="flex justify-center py-1"><ChevronDown className="w-4 h-4 text-slate-300" /></div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { icon: "👤", label: "Patient Dashboard",      sub: "Live feedback · Progress · Gamification", cls: "from-blue-700 to-blue-500" },
                { icon: "🩺", label: "Physiotherapist Portal", sub: "Oversight · Prescriptions · Adherence",  cls: "from-teal-700 to-teal-500" },
              ].map(o => (
                <div key={o.label} className={`bg-gradient-to-br ${o.cls} rounded-2xl p-4 flex items-center gap-3 text-white`}>
                  <span className="text-2xl flex-shrink-0">{o.icon}</span>
                  <div>
                    <div className="font-bold text-xs leading-tight" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{o.label}</div>
                    <div className="text-xs opacity-70 mt-0.5 leading-tight">{o.sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Tech details */}
        <div className="space-y-4">
          {[
            { icon: Cpu,        title: "Computer Vision Layer",   color: "text-blue-600",   bg: "bg-blue-50",
              items: ["MediaPipe Pose Estimation (33 landmarks)", "Real-time markerless skeletal tracking", "Knee and hip joint angle computation", "< 50 ms end-to-end inference latency", "Runs on standard consumer hardware"] },
            { icon: Brain,      title: "Clinical Intelligence",   color: "text-teal-600",   bg: "bg-teal-50",
              items: ["Exercise Quality Score (0–100 scale)", "ROM Achievement weighted at 40%", "Movement Control weighted at 25%", "Form Assessment weighted at 20%", "Hold Duration weighted at 15%"] },
            { icon: Database,   title: "Platform & Compliance",   color: "text-indigo-600", bg: "bg-indigo-50",
              items: ["Dual patient and physiotherapist portal", "Real-time analytics and outcome reporting", "Gamification and engagement engine", "Clinical reporting suite for providers", "HIPAA-compliant encrypted data storage"] },
          ].map(card => (
            <Card key={card.title} className="p-5">
              <div className="flex items-center gap-2.5 mb-3">
                <div className={`w-8 h-8 ${card.bg} rounded-xl flex items-center justify-center flex-shrink-0`}>
                  <card.icon className={`w-4 h-4 ${card.color}`} />
                </div>
                <h4 className="font-bold text-slate-800" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{card.title}</h4>
              </div>
              <ul className="space-y-1.5">
                {card.items.map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-slate-600">
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-300 flex-shrink-0" />{item}
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </div>

      {/* Quality score composition */}
      <div className="rounded-2xl bg-gradient-to-br from-blue-800 to-teal-700 p-7 text-white">
        <h4 className="font-black text-2xl mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Exercise Quality Score</h4>
        <p className="text-blue-200 text-sm mb-6">Clinically grounded weighting — no arbitrary "optimal" angle enforcement. Joint angles inform, not dictate.</p>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { label: "ROM Achievement",  pct: 40, desc: "Degree of target ROM reached per rep"  },
            { label: "Movement Control", pct: 25, desc: "Smoothness, steadiness, and pacing"    },
            { label: "Form Assessment",  pct: 20, desc: "Joint alignment and postural quality"  },
            { label: "Hold Duration",    pct: 15, desc: "Time held at the target position"      },
          ].map(q => (
            <div key={q.label} className="bg-white/15 rounded-2xl p-5 text-center">
              <div className="text-5xl font-black mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{q.pct}%</div>
              <div className="font-bold text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{q.label}</div>
              <div className="text-blue-200 text-xs mt-1 leading-tight">{q.desc}</div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-4 gap-2">
          {[
            ["Needs Improvement", "bg-red-400/25 text-red-100"],
            ["Satisfactory",      "bg-yellow-400/20 text-yellow-100"],
            ["Good",              "bg-blue-400/20 text-blue-100"],
            ["Excellent",         "bg-emerald-400/25 text-emerald-100"],
          ].map(([label, cls]) => (
            <div key={label} className={`rounded-xl p-3 text-center text-xs font-bold ${cls}`}>{label}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

const patientNav = [
  { id: "dashboard",     label: "Dashboard",         icon: LayoutDashboard },
  { id: "session",       label: "Exercise Session",  icon: Video           },
  { id: "virtual-physio",label: "Virtual Physio",    icon: MessageCircle   },
  { id: "progress",      label: "My Progress",       icon: TrendingUp      },
  { id: "achievements",  label: "Achievements",      icon: Trophy          },
];

const physioNav = [
  { id: "patients",     label: "Patient Overview",    icon: Users       },
  { id: "prescription", label: "Prescribe Exercises", icon: ClipboardList },
  { id: "monitor",      label: "Monitor Progress",    icon: BarChart3   },
  { id: "adherence",    label: "Review Adherence",    icon: CheckSquare },
];

function Sidebar({ role, screen, setScreen, setRole, open, close }: {
  role: "patient"|"physio"; screen: string;
  setScreen: (s: string) => void; setRole: (r: "patient"|"physio") => void;
  open: boolean; close: () => void;
}) {
  const nav = role === "patient" ? patientNav : physioNav;

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/50 z-20 lg:hidden backdrop-blur-sm" onClick={close} />}
      <aside className={`fixed top-0 left-0 h-full w-60 bg-slate-900 flex flex-col z-30 transition-transform duration-300 ease-in-out ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        {/* Logo */}
        <div className="px-5 py-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-teal-400 rounded-xl flex items-center justify-center flex-shrink-0">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-black text-white text-sm leading-tight" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Smart Knee</div>
              <div className="text-slate-500 text-xs">Rehab Assistant</div>
            </div>
          </div>
        </div>

        {/* Role switcher */}
        <div className="px-3 py-3 border-b border-slate-800">
          <div className="flex bg-slate-800 rounded-xl p-1 gap-1">
            {(["patient","physio"] as const).map(r => (
              <button key={r} onClick={() => { setRole(r); setScreen(r === "patient" ? "dashboard" : "patients"); close(); }}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${role === r ? "bg-blue-600 text-white shadow-sm" : "text-slate-400 hover:text-white"}`}>
                {r === "patient" ? "Patient" : "Physio"}
              </button>
            ))}
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
          <div className="text-xs text-slate-600 font-bold uppercase tracking-wider px-3 mb-2">
            {role === "patient" ? "My Rehabilitation" : "Clinical Tools"}
          </div>
          {nav.map(item => (
            <button key={item.id} onClick={() => { setScreen(item.id); close(); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all text-left ${screen === item.id ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800"}`}>
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {item.label}
            </button>
          ))}

          <div className="pt-3">
            <div className="text-xs text-slate-600 font-bold uppercase tracking-wider px-3 mb-2">Platform</div>
            <button onClick={() => { setScreen("architecture"); close(); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all text-left ${screen === "architecture" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800"}`}>
              <Cpu className="w-4 h-4 flex-shrink-0" />
              Architecture
            </button>
          </div>
        </nav>

        {/* User */}
        <div className="px-4 py-4 border-t border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-teal-400 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
              {role === "patient" ? "MC" : "KP"}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white truncate">{role === "patient" ? "Margaret Chen" : "Dr. K. Patel"}</div>
              <div className="text-xs text-slate-500 truncate">{role === "patient" ? "Patient · TKR Recovery" : "Senior Physiotherapist"}</div>
            </div>
            <Settings className="w-4 h-4 text-slate-500 flex-shrink-0" />
          </div>
        </div>
      </aside>
    </>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

const screenTitles: Record<string, string> = {
  dashboard:      "Patient Dashboard",
  session:        "Live Exercise Session",
  "virtual-physio":"Virtual Physiotherapist",
  progress:       "Recovery Progress",
  achievements:   "Recovery Journey",
  patients:       "Patient Overview",
  prescription:   "Exercise Prescription",
  monitor:        "Monitor Progress",
  adherence:      "Adherence Review",
  architecture:   "System Architecture",
};

export default function App() {
  const [role, setRole]   = useState<"patient"|"physio">("patient");
  const [screen, setScreen] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const go = (s: string) => { setScreen(s); setSidebarOpen(false); };

  const renderScreen = () => {
    switch (screen) {
      case "dashboard":      return <PatientDashboard go={go} />;
      case "session":        return <LiveExerciseSession />;
      case "virtual-physio": return <VirtualPhysiotherapist />;
      case "progress":       return <RecoveryProgress />;
      case "achievements":   return <AchievementsScreen />;
      case "patients":       return <PatientOverview go={go} />;
      case "prescription":   return <ExercisePrescription />;
      case "monitor":        return <MonitorProgress />;
      case "adherence":      return <ReviewAdherence />;
      case "architecture":   return <ArchitectureScreen />;
      default:               return <PatientDashboard go={go} />;
    }
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      <Toaster position="top-right" richColors />

      <Sidebar role={role} screen={screen} setScreen={setScreen} setRole={setRole}
        open={sidebarOpen} close={() => setSidebarOpen(false)} />

      <div className="flex-1 lg:ml-60 flex flex-col min-h-screen bg-[#EEF2F7]">
        {/* Header */}
        <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b border-slate-200 px-5 h-14 flex items-center gap-4">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-1.5 rounded-lg hover:bg-slate-100 transition-colors">
            <Menu className="w-5 h-5 text-slate-600" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="font-bold text-slate-800 text-sm truncate">{screenTitles[screen]}</h1>
          </div>
          <div className="flex items-center gap-2.5">
            <button className="relative p-2 rounded-xl hover:bg-slate-100 transition-colors">
              <Bell className="w-5 h-5 text-slate-500" />
              <div className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
            </button>
            <div className="h-6 w-px bg-slate-200" />
            <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold ${role === "patient" ? "bg-blue-50 text-blue-700 border border-blue-200" : "bg-teal-50 text-teal-700 border border-teal-200"}`}>
              <UserCircle className="w-3.5 h-3.5" />
              {role === "patient" ? "Patient" : "Physiotherapist"}
            </div>
          </div>
        </header>

        {/* Main content with transition */}
        <main className="flex-1 p-5 lg:p-6 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={screen}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.18, ease: "easeOut" }}
            >
              {renderScreen()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
